# commerce-snippets
Collection of WooCommerce and ClassicCommerce Customization Snippets on [YouTube](https://www.youtube.com/c/techiepress)

- [Add Automatic fees to Checkout](/add-to-cart)
- [Remove unused checkout fields](/remove-checkout-fields)
